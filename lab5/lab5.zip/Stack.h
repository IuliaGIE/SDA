#include <stdlib.h>
//#include "Stack.h"
typedef struct StackNode{
int elem;
struct StackNode *next;
}StackNode;
typedef struct Stack{
StackNode* head;
long size;
}Stack;
Stack* createStack() {
    Stack* stack = (Stack*)malloc(sizeof(Stack));
    stack->head = NULL;
    stack->size = 0;
    return stack;
}

int isStackEmpty(Stack* stack) {
    return (stack->head == NULL);
}

void push(Stack* stack, int elem) {
    StackNode* node = (StackNode*)malloc(sizeof(StackNode));
    node->elem = elem;
    node->next = stack->head;
    stack->head = node;
    stack->size++;
}

int top(Stack* stack) {
    if (isStackEmpty(stack)) {
        // nu exista niciun element in stiva
        return NULL;
    }
    return stack->head->elem;
}

int pop(Stack* stack) {
    if (isStackEmpty(stack)) {
        // nu exista niciun element in stiva
        return NULL;
    }
    StackNode* node = stack->head;
    stack->head = node->next;
    stack->size--;
    int elem = node->elem;
    free(node);
    return elem;
}

void destroyStack(Stack* stack) {
    while (!isStackEmpty(stack)) {
        pop(stack);
    }
    free(stack);
}
